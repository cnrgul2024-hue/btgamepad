package com.example.btgamepad

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

class StickView(ctx: Context, private val onMove: (Int, Int) -> Unit) : View(ctx) {
    private var kx = 0f
    private var ky = 0f
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF333333.toInt() }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF999999.toInt() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy)
        c.drawCircle(cx, cy, r, basePaint)
        c.drawCircle(cx + kx * r * 0.6f, cy + ky * r * 0.6f, r * 0.4f, knobPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val r = minOf(width, height) / 2f * 0.6f
                var dx = (e.x - width / 2f) / r
                var dy = (e.y - height / 2f) / r
                val len = hypot(dx, dy)
                if (len > 1f) { dx /= len; dy /= len }
                kx = dx
                ky = dy
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { kx = 0f; ky = 0f }
        }
        onMove((kx * 127).toInt(), (ky * 127).toInt())
        invalidate()
        return true
    }
}

class MainActivity : Activity() {
    companion object {
        // Report ID 1: 16 buton, 1 hat (4 bit + 4 bit dolgu), 4 eksen (X, Y, Z, Rz)
        private val D = intArrayOf(
            0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
            0x05, 0x01, 0x09, 0x39, 0x15, 0x01, 0x25, 0x08, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
            0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
            0x75, 0x04, 0x95, 0x01, 0x81, 0x03,
            0x35, 0x00, 0x45, 0x00, 0x65, 0x00,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35,
            0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
            0xC0
        )
        val DESC = ByteArray(D.size) { D[it].toByte() }
    }

    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var adapter: BluetoothAdapter? = null
    private lateinit var status: TextView

    private var buttons = 0
    private var du = false
    private var dd = false
    private var dl = false
    private var dr = false
    private var lx = 0
    private var ly = 0
    private var rx = 0
    private var ry = 0

    private val dp by lazy { resources.displayMetrics.density }

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            runOnUiThread { status.text = if (registered) "Hazır\n\"Görünür yap\" ile eşleş" else "Kayıt yok" }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            host = if (state == BluetoothProfile.STATE_CONNECTED) device else null
            runOnUiThread { status.text = if (host != null) "Bağlı" else "Bağlı değil" }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        } else {
            setupHid()
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) setupHid()
        else status.text = "Bluetooth izni gerekli"
    }

    private fun setupHid() {
        val a: BluetoothAdapter? = getSystemService(BluetoothManager::class.java).adapter
        adapter = a
        if (a == null || !a.isEnabled) {
            status.text = "Bluetooth'u aç, uygulamayı yeniden başlat"
            return
        }
        a.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "BT Gamepad", "Gamepad", "BtGamepad", BluetoothHidDevice.SUBCLASS1_COMBO, DESC
                )
                h.registerApp(sdp, null, null, mainExecutor, cb)
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    private fun hatValue(): Int = when {
        du && dr -> 2
        dr && dd -> 4
        dd && dl -> 6
        dl && du -> 8
        du -> 1
        dr -> 3
        dd -> 5
        dl -> 7
        else -> 0
    }

    private fun send() {
        val h = hid ?: return
        val d = host ?: return
        val data = byteArrayOf(
            (buttons and 0xFF).toByte(), ((buttons shr 8) and 0xFF).toByte(),
            hatValue().toByte(),
            lx.toByte(), ly.toByte(), rx.toByte(), ry.toByte()
        )
        h.sendReport(d, 1, data)
    }

    private fun setBit(mask: Int, down: Boolean) {
        buttons = if (down) buttons or mask else buttons and mask.inv()
        send()
    }

    private fun makeDiscoverable() {
        startActivity(
            Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
        )
    }

    private fun pickDevice() {
        val h = hid ?: run { status.text = "Hazır değil"; return }
        val list = adapter?.bondedDevices?.toList() ?: return
        val names = list.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Cihaz seç")
            .setItems(names) { _, i -> h.connect(list[i]) }
            .show()
    }

    // ---------- Arayüz ----------

    private fun lin(horizontal: Boolean) = LinearLayout(this).apply {
        orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
    }

    private fun LinearLayout.put(v: View, weight: Float = 1f): LinearLayout {
        val m = (4 * dp).toInt()
        val p = if (orientation == LinearLayout.HORIZONTAL)
            LinearLayout.LayoutParams(0, MATCH_PARENT, weight)
        else
            LinearLayout.LayoutParams(MATCH_PARENT, 0, weight)
        p.setMargins(m, m, m, m)
        addView(v, p)
        return this
    }

    private fun btn(label: String, f: (Boolean) -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        minWidth = 0
        minHeight = 0
        minimumWidth = 0
        minimumHeight = 0
        setPadding(0, 0, 0, 0)
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; f(true) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; f(false) }
            }
            true
        }
    }

    private fun act(label: String, f: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { f() }
    }

    private fun cluster(top: View, l: View, r: View, bottom: View) = lin(false)
        .put(lin(true).put(View(this)).put(top).put(View(this)))
        .put(lin(true).put(l).put(View(this)).put(r))
        .put(lin(true).put(View(this)).put(bottom).put(View(this)))

    private fun buildUi(): View {
        status = TextView(this).apply {
            text = "Başlatılıyor..."
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            textSize = 16f
        }

        val colL = lin(false)
            .put(lin(true).put(btn("L2") { setBit(1 shl 8, it) }).put(btn("L1") { setBit(1 shl 6, it) }), 0.7f)
            .put(StickView(this) { x, y -> lx = x; ly = y; send() }, 1.2f)
            .put(
                cluster(
                    btn("▲") { du = it; send() },
                    btn("◀") { dl = it; send() },
                    btn("▶") { dr = it; send() },
                    btn("▼") { dd = it; send() }
                ), 1.2f
            )

        val colC = lin(false)
            .put(status, 0.8f)
            .put(act("Görünür yap") { makeDiscoverable() }, 0.5f)
            .put(act("Eşleşmiş cihaza bağlan") { pickDevice() }, 0.5f)
            .put(lin(true).put(btn("SELECT") { setBit(1 shl 10, it) }).put(btn("START") { setBit(1 shl 11, it) }), 0.6f)
            .put(lin(true).put(btn("L3") { setBit(1 shl 13, it) }).put(btn("R3") { setBit(1 shl 14, it) }), 0.6f)

        val colR = lin(false)
            .put(lin(true).put(btn("R1") { setBit(1 shl 7, it) }).put(btn("R2") { setBit(1 shl 9, it) }), 0.7f)
            .put(
                cluster(
                    btn("Y") { setBit(1 shl 4, it) },
                    btn("X") { setBit(1 shl 3, it) },
                    btn("B") { setBit(1 shl 1, it) },
                    btn("A") { setBit(1, it) }
                ), 1.2f
            )
            .put(StickView(this) { x, y -> rx = x; ry = y; send() }, 1.2f)

        return lin(true).apply {
            setBackgroundColor(0xFF111111.toInt())
            val p = (8 * dp).toInt()
            setPadding(p, p, p, p)
            put(colL, 1f)
            put(colC, 0.9f)
            put(colR, 1f)
        }
    }

    override fun onDestroy() {
        try {
            hid?.unregisterApp()
            adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
